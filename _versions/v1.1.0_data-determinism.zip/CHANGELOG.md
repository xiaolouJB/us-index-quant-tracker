# 版本变更记录（CHANGELOG）

> 每个版本在 `_versions/` 下有对应 zip 快照（仅打包 SKILL.md / references / scripts / viewer 等逻辑文件，不含每日报告与数据）。
> **回退方法**：解压对应 `_versions/vX.Y.Z_*.zip`，覆盖当前同名文件即可。

---

## v1.0.0 — 基线（2026-06-26）
进化重构前的存档基线。此版本已包含：
- 双核路由 + 灯号系统 + 模块 A–R / L-M-N / Q
- 数据脚本：fetch_all / fetch_fred / fetch_technicals / fetch_options_walls / fetch_dark_pool / fetch_sentiment / fetch_fund_flow / sanity_check / clear_snapshot
- 报告模板：今日操作速览 + 📚小白必读(五维体检) + 进阶数据区 + 大白话深度解读
- 教学层 references/beginner_layer.md
- 已知待改进项：数字靠模型手抄（跨模型易错）、indicators.csv 有重复行、第4节灯号含金额、部分估值字段靠人工 WebSearch。

## v1.1.0 — 数据确定性重构（2026-06-26 ✅已完成）
**目标达成：换任何模型，报告里的数字/评级/灯号/天气/操作档位完全一致，根治跨模型数据错乱。**
- 新增 `scripts/run_inspection.py`：一条命令跑完整条管线（清空→8个fetcher→体检），输出唯一权威数据源 `data/report_data.json`，每字段带状态(OK/MISSING/STALE)，核心缺失以退出码2阻断。
- 新增 `scripts/build_report.py`：**确定性装配器**。数字从 report_data.json 代码注入；指标"水平/影响"、5维评级、总灯号、天气、操作档位全部规则引擎自动算；模型只写 `data/narrative.json` 的人工字段+文字。报告自带"数据可信度水印"，缺失字段显示 `⚠️待核实`。
- 新增 `references/narrative_schema.md`：模型唯一需手写文件的填写指南。
- fetch_all.py 增加当日涨跌幅入快照（ndx/spx/qqq/spy_chg_pct），价格行不再靠模型手算。
- SKILL.md 流程改为极简3步：run_inspection → 写 narrative.json → build_report。
- run_pipeline.bat 升级为调用 run_inspection.py。
- 注：viewer/ 已由用户移除，报告改为直接阅读 Markdown。

新工作流：
```
python scripts/run_inspection.py        # 1. 一键取数+体检
# 2. 模型按 narrative_schema.md 写 data/narrative.json（WebSearch人工字段+文字判断）
python scripts/build_report.py          # 3. 确定性装配报告
```

## v1.2.0 — 数据完整性修复（规划中）
- indicators.csv 去重+排序
- SKILL.md 第4节灯号去金额、改档位
- 新增 fetch_valuation.py（CAPE/Top10/巴菲特脚本化）

## v1.3.0 — 小白可读性升级（规划中）
- 报告加"3秒结论"卡
- 进阶区默认折叠
- viewer 可视化仪表盘（5维红绿灯+估值温度计）
