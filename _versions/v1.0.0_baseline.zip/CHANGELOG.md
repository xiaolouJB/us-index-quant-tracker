# 版本变更记录（CHANGELOG）

> 每个版本在 `_versions/` 下有对应 zip 快照（仅打包 SKILL.md / references / scripts / viewer 等逻辑文件，不含每日报告与数据）。
> **回退方法**：解压对应 `_versions/vX.Y.Z_*.zip`，覆盖当前同名文件即可。

---

## v1.0.0 — 基线（2026-06-26）
进化重构前的存档基线。此版本已包含：
- 双核路由 + 灯号系统 + 模块 A–R / L-M-N / Q
- 数据脚本：fetch_all / fetch_fred / fetch_technicals / fetch_options_walls / fetch_dark_pool / fetch_sentiment / fetch_fund_flow / sanity_check / clear_snapshot
- 报告模板：今日操作速览 + 📚小白必读(五维体检) + 进阶数据区 + 大白话深度解读
- 教学层 references/beginner_layer.md
- 已知待改进项：数字靠模型手抄（跨模型易错）、indicators.csv 有重复行、第4节灯号含金额、部分估值字段靠人工 WebSearch。

## v1.1.0 — 数据确定性重构（规划中）
- 新增 run_inspection.py 总指挥脚本（一条命令跑完管线，输出带状态的 report_data.json）
- 新增 build_report.py（数字由代码注入报告，模型只写 narrative.json）
- report_template.md 改为 {{占位符}} 模板
- 目标：换任何模型，报告里的数字都一致，根治跨模型数据错乱

## v1.2.0 — 数据完整性修复（规划中）
- indicators.csv 去重+排序
- SKILL.md 第4节灯号去金额、改档位
- 新增 fetch_valuation.py（CAPE/Top10/巴菲特脚本化）

## v1.3.0 — 小白可读性升级（规划中）
- 报告加"3秒结论"卡
- 进阶区默认折叠
- viewer 可视化仪表盘（5维红绿灯+估值温度计）
